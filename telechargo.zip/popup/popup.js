document.addEventListener('DOMContentLoaded', function() {
    // Gestion des onglets
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        const tabName = button.dataset.tab;
        
        // Désactiver tous les onglets
        tabButtons.forEach(btn => btn.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));
        
        // Activer l'onglet sélectionné
        button.classList.add('active');
        document.getElementById(tabName).classList.add('active');
      });
    });
    
    // Charger les téléchargements récents
    loadRecentDownloads();
    
    // Charger les paramètres
    loadSettings();
    
    // Écouteur pour le bouton d'enregistrement des paramètres
    document.getElementById('save-settings').addEventListener('click', saveSettings);
  });
  
  // Fonction pour charger les téléchargements récents
  function loadRecentDownloads() {
    const downloadsList = document.getElementById('recent-downloads');
    
    browser.storage.local.get("downloadHistory", (result) => {
      const history = result.downloadHistory || [];
      
      if (history.length === 0) {
        downloadsList.innerHTML = '<p class="empty-message">Aucun téléchargement récent</p>';
        return;
      }
      
      downloadsList.innerHTML = '';
      
      // Afficher les téléchargements du plus récent au plus ancien
      history.reverse().forEach(item => {
        const downloadItem = document.createElement('div');
        downloadItem.className = 'download-item';
        
        const filename = item.filename.split('/').pop();
        
        downloadItem.innerHTML = `
          <div class="download-name">${filename}</div>
          <div class="download-category">${item.category}</div>
        `;
        
        downloadsList.appendChild(downloadItem);
      });
    });
  }
  
  // Fonction pour charger les paramètres
  function loadSettings() {
    browser.storage.local.get("userFolders", (result) => {
      const folders = result.userFolders || {
        images: "Images",
        documents: "Documents",
        audio: "Audio",
        video: "Video",
        archives: "Archives",
        other: "Autres"
      };
      
      document.getElementById('images-folder').value = folders.images;
      document.getElementById('documents-folder').value = folders.documents;
      document.getElementById('audio-folder').value = folders.audio;
      document.getElementById('video-folder').value = folders.video;
      document.getElementById('archives-folder').value = folders.archives;
      document.getElementById('other-folder').value = folders.other;
    });
  }
  
  // Fonction pour enregistrer les paramètres
  function saveSettings() {
    const userFolders = {
      images: document.getElementById('images-folder').value,
      documents: document.getElementById('documents-folder').value,
      audio: document.getElementById('audio-folder').value,
      video: document.getElementById('video-folder').value,
      archives: document.getElementById('archives-folder').value,
      other: document.getElementById('other-folder').value
    };
    
    browser.storage.local.set({ userFolders }, () => {
      // Afficher un message de confirmation temporaire
      const saveBtn = document.getElementById('save-settings');
      const originalText = saveBtn.textContent;
      
      saveBtn.textContent = 'Enregistré !';
      saveBtn.disabled = true;
      
      setTimeout(() => {
        saveBtn.textContent = originalText;
        saveBtn.disabled = false;
      }, 1500);
    });
  }
  