const defaultFolders = {
    images: "Images",
    documents: "Documents",
    audio: "Audio",
    video: "Video",
    archives: "Archives",
    other: "Autres"
  };
  
  // Types de fichiers par catégorie
  const fileTypes = {
    images: [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp"],
    documents: [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".odt", ".ods", ".odp"],
    audio: [".mp3", ".wav", ".ogg", ".flac", ".aac", ".m4a"],
    video: [".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm"],
    archives: [".zip", ".rar", ".7z", ".tar", ".gz"]
  };
  
  // Charger la configuration utilisateur ou utiliser les valeurs par défaut
  let userFolders = defaultFolders;
  
  browser.storage.local.get("userFolders", (result) => {
    if (result.userFolders) {
      userFolders = result.userFolders;
    } else {
      // Sauvegarder les dossiers par défaut
      browser.storage.local.set({ userFolders: defaultFolders });
    }
  });
  
  // Fonction pour déterminer la catégorie d'un fichier
  function getFileCategory(filename) {
    const extension = "." + filename.split('.').pop().toLowerCase();
    
    for (const category in fileTypes) {
      if (fileTypes[category].includes(extension)) {
        return category;
      }
    }
    
    return "other";
  }
  
  // Écouteur d'événement pour les nouveaux téléchargements
  browser.downloads.onCreated.addListener((downloadItem) => {
    // Extraire le nom du fichier de l'URL
    const filename = downloadItem.filename || 
                     downloadItem.url.split('/').pop() || 
                     "fichier";
    
    // Déterminer la catégorie
    const category = getFileCategory(filename);
    
    // Obtenir le dossier correspondant
    const targetFolder = userFolders[category];
    
    // Firefox ne permet pas de changer automatiquement le dossier de téléchargement,
    // mais nous pouvons suivre le téléchargement pour l'organiser ultérieurement
    // ou suggérer à l'utilisateur où le placer
    
    // Stocker l'information sur ce téléchargement
    const downloadInfo = {
      id: downloadItem.id,
      filename: filename,
      category: category,
      suggestedFolder: targetFolder,
      timestamp: Date.now()
    };
    
    // Stocker cette information dans l'historique des téléchargements
    browser.storage.local.get("downloadHistory", (result) => {
      let history = result.downloadHistory || [];
      history.push(downloadInfo);
      // Limiter l'historique à 100 entrées
      if (history.length > 100) {
        history = history.slice(-100);
      }
      browser.storage.local.set({ downloadHistory: history });
    });
  });